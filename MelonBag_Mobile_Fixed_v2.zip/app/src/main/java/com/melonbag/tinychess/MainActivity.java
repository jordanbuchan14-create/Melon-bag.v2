package com.melonbag.tinychess;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.*;
import android.view.*;
import android.content.Context;
import android.media.AudioManager;
import android.media.ToneGenerator;
import java.util.*;

public class MainActivity extends Activity {
    GameView game;
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        game = new GameView(this);
        setContentView(game);
    }
    @Override protected void onPause(){ super.onPause(); if(game!=null) game.pauseGame(); }
    @Override protected void onResume(){ super.onResume(); if(game!=null) game.resumeGame(); }
}

class GameView extends View {
    static final int TITLE=0, PLAYING=1, GAMEOVER=2, COMPLETE=3;
    Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    ToneGenerator tone;
    int W,H,boardTop,boardBottom,cell,cols=8,rows;
    int level=1,score=0,goal=6,state=TITLE;
    int px,py,dx=1,dy=0,ndx=1,ndy=0;
    float walkPhase=0;
    long lastStep=0;
    final ArrayList<Point> body=new ArrayList<>(), obstacles=new ArrayList<>();
    Point melon=new Point(1,1);
    float downX,downY;
    boolean hasTouch=false;
    final Random deterministic=new Random();
    final HandlerLoop loop = new HandlerLoop();

    GameView(Context c){
        super(c); setFocusable(true);
        tone=new ToneGenerator(AudioManager.STREAM_MUSIC,55);
    }

    void layoutBoard(){
        W=getWidth(); H=getHeight();
        boardTop=Math.round(H*.075f);
        boardBottom=Math.round(H*.72f);
        float usableW=W-24f, usableH=boardBottom-boardTop-12f;
        cell=Math.max(34,Math.min((int)(usableW/cols),(int)(usableH/8f)));
        rows=Math.max(8,(int)(usableH/cell));
        // Recalculate so the board is centered and leaves room for controls.
        cell=Math.min((int)(usableW/cols),(int)(usableH/rows));
        if(cell<34) cell=34;
        boardBottom=boardTop+rows*cell;
    }

    int boardLeft(){ return (W-cols*cell)/2; }
    int cx(int x){ return boardLeft()+x*cell+cell/2; }
    int cy(int y){ return boardTop+y*cell+cell/2; }

    void startLevel(){
        layoutBoard(); state=PLAYING; score=0; goal=5+level;
        body.clear(); obstacles.clear(); px=cols/2; py=rows/2; dx=1;dy=0;ndx=1;ndy=0;
        buildLevel(); placeMelon(0); lastStep=System.currentTimeMillis(); loop.start(); invalidate();
    }

    void buildLevel(){
        // Fixed, repeatable obstacle layout per level.
        int count=Math.min(1+level/2,7);
        for(int i=0;i<count;i++){
            int x=1+((i*3+level*2)%Math.max(2,cols-2));
            int y=1+((i*5+level)%Math.max(2,rows-2));
            if(Math.abs(x-px)+Math.abs(y-py)<3){x=1;y=Math.min(rows-2,rows/2);}
            if(x==px&&y==py) x=Math.max(1,px-2);
            obstacles.add(new Point(x,y));
        }
    }

    boolean blocked(int x,int y){
        if(x==px&&y==py)return true;
        for(Point b:body) if(b.x==x&&b.y==y)return true;
        for(Point o:obstacles) if(o.x==x&&o.y==y)return true;
        return false;
    }

    void placeMelon(int index){
        // Deliberately deterministic spawn pattern: same level = same melon route.
        int[][] pattern={
            {1,1},{6,1},{1,3},{6,3},{2,5},{5,5},{1,7},{6,7},
            {3,2},{4,6},{2,2},{5,2},{2,6},{5,6},{3,7},{4,1}
        };
        for(int k=0;k<pattern.length;k++){
            int i=(index+k+level*2)%pattern.length;
            int x=Math.min(cols-1,pattern[i][0]), y=Math.min(rows-1,pattern[i][1]);
            if(!blocked(x,y)){ melon.set(x,y); return; }
        }
        melon.set(1,1);
    }

    void step(){
        if(state!=PLAYING)return;
        dx=ndx;dy=ndy;
        body.add(0,new Point(px,py));
        px+=dx;py+=dy;walkPhase+=Math.PI/2;
        boolean bad=px<0||py<0||px>=cols||py>=rows;
        for(int i=3;i<body.size()&&!bad;i++) if(body.get(i).x==px&&body.get(i).y==py)bad=true;
        for(Point o:obstacles)if(o.x==px&&o.y==py)bad=true;
        if(bad){state=GAMEOVER; beep(3); loop.stop(); invalidate();return;}
        if(px==melon.x&&py==melon.y){
            score++; beep(2); placeMelon(score);
            if(score>=goal){state=COMPLETE; beep(4); loop.stop(); invalidate();return;}
        }
        if(body.size()>score) body.remove(body.size()-1);
        lastStep=System.currentTimeMillis(); invalidate();
    }

    void beep(int kind){
        try{
            if(kind==1) tone.startTone(ToneGenerator.TONE_PROP_BEEP,45);
            else if(kind==2) tone.startTone(ToneGenerator.TONE_PROP_ACK,75);
            else if(kind==3) tone.startTone(ToneGenerator.TONE_PROP_NACK,160);
            else { tone.startTone(ToneGenerator.TONE_PROP_ACK,70); postDelayed(()->tone.startTone(ToneGenerator.TONE_PROP_ACK,100),90); }
        }catch(Exception ignored){}
    }

    void pauseGame(){ loop.stop(); }
    void resumeGame(){ if(state==PLAYING) loop.start(); invalidate(); }

    @Override protected void onDraw(Canvas c){
        super.onDraw(c); layoutBoard();
        drawBackground(c); drawBoard(c);
        if(state==PLAYING){ drawHud(c); drawControls(c); }
        else if(state==TITLE) drawPanel(c,"MELON BAG","Tiny man. Giant chessboard.\nVery large bag.","START GAME");
        else if(state==GAMEOVER) drawPanel(c,"BAG SPILLED!","Level "+level+"  •  Melons: "+score,"RESTART LEVEL");
        else drawPanel(c,"LEVEL COMPLETE!","Level "+level+" cleared  •  Bag size "+(score+1),"NEXT LEVEL");
    }

    void drawBackground(Canvas c){
        c.drawColor(Color.rgb(16,23,18));
        p.setShader(new RadialGradient(W/2f,H*.35f,Math.max(W,H)*.75f,Color.TRANSPARENT,Color.argb(150,0,0,0),Shader.TileMode.CLAMP));
        c.drawRect(0,0,W,H,p); p.setShader(null);
    }

    void drawBoard(Canvas c){
        int left=boardLeft();
        for(int y=0;y<rows;y++)for(int x=0;x<cols;x++){
            p.setStyle(Paint.Style.FILL); p.setColor(((x+y)&1)==0?Color.rgb(77,118,80):Color.rgb(216,178,120));
            c.drawRect(left+x*cell,boardTop+y*cell,left+(x+1)*cell+1,boardTop+(y+1)*cell+1,p);
        }
        p.setTextAlign(Paint.Align.CENTER);p.setTextSize(cell*.62f);p.setColor(Color.argb(65,255,255,255));
        c.drawText("R",cx(0),cy(0)+cell*.2f,p);c.drawText("N",cx(cols-1),cy(0)+cell*.2f,p);
        c.drawText("P",cx(1),cy(rows-1)+cell*.2f,p);c.drawText("Q",cx(cols-2),cy(rows-1)+cell*.2f,p);
        for(Point o:obstacles){float x=cx(o.x),y=cy(o.y),s=cell*.24f;p.setColor(Color.rgb(150,88,39));c.drawRect(x-s,y-s,x+s,y+s,p);p.setColor(Color.rgb(214,155,82));c.drawRect(x-s*.6f,y-s*.7f,x+s*.6f,y-s*.35f,p);}
        drawMelon(c,melon.x,melon.y);
        for(int i=body.size()-1;i>=0;i--)drawMan(c,body.get(i),.64f,i);
        drawMan(c,new Point(px,py),1f,0);
    }

    void drawMelon(Canvas c,int x,int y){float xx=cx(x),yy=cy(y),r=cell*.22f;p.setStyle(Paint.Style.FILL);p.setColor(Color.rgb(113,166,57));c.drawCircle(xx,yy,r,p);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(2);p.setColor(Color.rgb(42,78,32));c.drawCircle(xx,yy,r,p);p.setStyle(Paint.Style.FILL);p.setColor(Color.rgb(48,90,43));c.drawRect(xx+r*.45f,yy-r*.75f,xx+r*.62f,yy-r*.42f,p);}

    void drawMan(Canvas c,Point q,float scale,int index){
        float x=cx(q.x),y=cy(q.y);float bob=index==0?(float)Math.sin(walkPhase)*cell*.045f:0;float swing=index==0?(float)Math.sin(walkPhase)*cell*.09f:0;
        c.save();c.translate(x,y+bob);c.scale(scale,scale);p.setStyle(Paint.Style.FILL);
        p.setColor(Color.rgb(30,30,38));p.setStrokeWidth(cell*.095f);p.setStrokeCap(Paint.Cap.ROUND);c.drawLine(-cell*.07f,cell*.23f,-cell*.10f+swing,cell*.43f,p);c.drawLine(cell*.07f,cell*.23f,cell*.10f-swing,cell*.43f,p);
        float bag=1+Math.min(body.size(),18)*.035f;p.setColor(Color.rgb(111,69,31));c.drawOval(-cell*.25f*bag,cell*.01f,cell*.25f*bag,cell*.53f*bag,p);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(3);p.setColor(Color.rgb(198,136,67));c.drawOval(-cell*.25f*bag,cell*.01f,cell*.25f*bag,cell*.53f*bag,p);p.setStyle(Paint.Style.FILL);
        p.setColor(Color.rgb(51,75,94));c.drawRect(-cell*.15f,-cell*.04f,cell*.15f,cell*.28f,p);p.setColor(Color.rgb(232,178,123));p.setStrokeWidth(cell*.075f);c.drawLine(-cell*.12f,0,-cell*.24f,cell*.17f,p);c.drawLine(cell*.12f,0,cell*.24f,cell*.17f,p);c.drawCircle(0,-cell*.2f,cell*.17f,p);p.setColor(Color.rgb(43,32,25));c.drawArc(-cell*.17f,-cell*.37f,cell*.17f,-cell*.03f,180,-180,true,p);p.setColor(Color.WHITE);c.drawRect(-cell*.075f,-cell*.22f,-cell*.03f,-cell*.185f,p);c.drawRect(cell*.03f,-cell*.22f,cell*.075f,-cell*.185f,p);c.restore();
    }

    void drawHud(Canvas c){
        p.setStyle(Paint.Style.FILL);p.setTextSize(Math.max(15,Math.min(20,W*.045f)));p.setColor(Color.WHITE);p.setShadowLayer(4,0,2,Color.BLACK);p.setTextAlign(Paint.Align.LEFT);c.drawText("MELONS  "+score+" / "+goal,14,28,p);p.setTextAlign(Paint.Align.RIGHT);c.drawText("LEVEL "+level,W-14,28,p);p.clearShadowLayer();
    }

    void drawControls(Canvas c){
        float r=Math.min(W*.105f,48);float cx=W/2f;float base=H*.88f;
        button(c,cx,base-r*1.15f,"↑",r);button(c,cx-r*1.2f,base,"←",r);button(c,cx+r*1.2f,base,"→",r);button(c,cx,base+r*1.15f,"↓",r);
    }
    void button(Canvas c,float x,float y,String s,float r){p.setColor(Color.argb(190,20,29,23));c.drawCircle(x,y,r,p);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(2);p.setColor(Color.argb(210,255,255,255));c.drawCircle(x,y,r,p);p.setStyle(Paint.Style.FILL);p.setColor(Color.WHITE);p.setTextAlign(Paint.Align.CENTER);p.setTextSize(r*.85f);c.drawText(s,x,y+r*.3f,p);}

    void drawPanel(Canvas c,String title,String sub,String button){
        p.setColor(Color.argb(232,18,30,23));c.drawRoundRect(W*.06f,H*.22f,W*.94f,H*.69f,28,28,p);
        p.setTextAlign(Paint.Align.CENTER);p.setColor(Color.WHITE);p.setTextSize(Math.min(48,W*.105f));c.drawText(title,W/2f,H*.35f,p);
        p.setTextSize(Math.min(18,W*.045f));p.setColor(Color.argb(225,255,255,255));String[] lines=sub.split("\\n");for(int i=0;i<lines.length;i++)c.drawText(lines[i],W/2f,H*.45f+i*25,p);
        p.setColor(Color.rgb(217,192,109));c.drawRoundRect(W*.22f,H*.55f,W*.78f,H*.65f,18,18,p);p.setColor(Color.rgb(25,32,22));p.setTextSize(Math.min(18,W*.045f));c.drawText(button,W/2f,H*.615f,p);
    }

    void chooseDirection(float x,float y){
        if(state!=PLAYING)return;
        float base=H*.88f,r=Math.min(W*.105f,48);
        if(dist(x,y,W/2f,base-r*1.15f)<r*1.35f){ if(dy!=1){ndx=0;ndy=-1;} return; }
        if(dist(x,y,W/2f,base+r*1.15f)<r*1.35f){ if(dy!=-1){ndx=0;ndy=1;} return; }
        if(dist(x,y,W/2f-r*1.2f,base)<r*1.35f){ if(dx!=1){ndx=-1;ndy=0;} return; }
        if(dist(x,y,W/2f+r*1.2f,base)<r*1.35f){ if(dx!=-1){ndx=1;ndy=0;} return; }
    }
    float dist(float a,float b,float c,float d){return (float)Math.hypot(a-c,b-d);}

    @Override public boolean onTouchEvent(MotionEvent e){
        if(e.getAction()==MotionEvent.ACTION_DOWN){downX=e.getX();downY=e.getY();hasTouch=true;return true;}
        if(e.getAction()==MotionEvent.ACTION_UP){
            float x=e.getX(),y=e.getY(),ax=x-downX,ay=y-downY;
            if(state==TITLE||state==GAMEOVER||state==COMPLETE){
                boolean button=y>H*.52f&&y<H*.70f;
                if(button||Math.max(Math.abs(ax),Math.abs(ay))<30){if(state==TITLE){level=1;startLevel();}else if(state==GAMEOVER){startLevel();}else{level++;startLevel();}}return true;
            }
            if(Math.max(Math.abs(ax),Math.abs(ay))>24){
                if(Math.abs(ax)>Math.abs(ay)){if(ax>0&&dx!=-1){ndx=1;ndy=0;}else if(ax<0&&dx!=1){ndx=-1;ndy=0;}}
                else{if(ay>0&&dy!=-1){ndx=0;ndy=1;}else if(ay<0&&dy!=1){ndx=0;ndy=-1;}}
            } else chooseDirection(x,y);
            return true;
        }
        return true;
    }

    class HandlerLoop implements Runnable{
        boolean running=false;
        void start(){if(running)return;running=true;post(this);}
        void stop(){running=false;removeCallbacks(this);}
        public void run(){if(!running)return;long now=System.currentTimeMillis();if(now-lastStep>=180){step();}postDelayed(this,16);}
    }
}
